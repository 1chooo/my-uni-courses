'''
匯入工具
'''
import pyautogui

'''
請在 Terminal 當中執行
取得滑鼠座標和游標上的色碼，協助我們定位
補充: 必須在 Terminal 當中執行
'''
pyautogui.displayMousePosition()